// ============================================================
// EMULADOR ANDROID
// ============================================================

let instalados = JSON.parse(localStorage.getItem('apps_instalados') || '{}');
let config = JSON.parse(localStorage.getItem('emulator_config') || '{}');
// Apps importados via ZIP (salvos em Base64 no localStorage)
let appsImportados = JSON.parse(localStorage.getItem('apps_importados') || '{}');

const CONFIG_PADRAO = {
  modelo: 'padrao',
  escala: 100,
  forcarLandscapeJogo: true,
  modoImersivo: true
};
config = { ...CONFIG_PADRAO, ...config };

const MODELOS = {
  compacto:  { nome: 'Compacto',    largura: 300, altura: 600,  desc: '300×600 · Celular pequeno' },
  padrao:    { nome: 'Padrão',      largura: 340, altura: 700,  desc: '340×700 · Celular comum' },
  grande:    { nome: 'Grande',      largura: 380, altura: 780,  desc: '380×780 · Celular grande' },
  tablet:    { nome: 'Tablet',      largura: 480, altura: 720,  desc: '480×720 · Tela grande' },
  horizontal:{ nome: 'Horizontal',  largura: 700, altura: 340,  desc: '700×340 · Fixo na horizontal' }
};

let catalogo = [];
let catalogoCarregado = false;
const EXTENSOES_ICONE = ['png', 'jpg', 'jpeg', 'webp'];

function salvarConfig() {
  localStorage.setItem('emulator_config', JSON.stringify(config));
}

function criarIconeApp(pasta, nome) {
  const img = document.createElement('img');
  let i = 0;
  const next = () => {
    if (i >= EXTENSOES_ICONE.length) {
      const ph = document.createElement('div');
      ph.className = 'placeholder';
      ph.textContent = '📦';
      if (img.parentNode) img.replaceWith(ph);
      return;
    }
    if (appsImportados[pasta]) {
      if (appsImportados[pasta].icon) {
        img.src = appsImportados[pasta].icon;
        return;
      }
      next();
    } else {
      img.src = `app/${pasta}/icon.${EXTENSOES_ICONE[i++]}`;
    }
  };
  img.alt = nome;
  img.onerror = next;
  next();
  return img;
}

async function lerNomeApp(pasta, fallback) {
  if (appsImportados[pasta]) return appsImportados[pasta].nome;
  try {
    const r = await fetch(`app/${pasta}/name.txt`, { cache: 'no-store' });
    if (r.ok) {
      const t = (await r.text()).trim();
      if (t) return t.split('\n')[0].trim();
    }
  } catch(e) {}
  return fallback;
}

async function lerIsGame(pasta) {
  if (appsImportados[pasta]) return appsImportados[pasta].isGame;
  try {
    const r = await fetch(`app/${pasta}/type.txt`, { cache: 'no-store' });
    if (!r.ok) return false;
    const txt = (await r.text()).toLowerCase();
    const limpo = txt.replace(/[\s:_\-]+/g, '');
    const m = limpo.match(/isgame[:=]?(true|false|1|0)/);
    if (m) return m[1] === 'true' || m[1] === '1';
    return /\btrue\b/.test(txt);
  } catch(e) { return false; }
}

// ============================================================
// ORIENTAÇÃO E MODELO
// ============================================================

function aplicarModelo() {
  const frame = document.getElementById('phone-frame');
  const m = MODELOS[config.modelo] || MODELOS.padrao;

  frame.classList.remove('immersive', 'show-bars');
  frame.style.setProperty('--phone-w', m.largura + 'px');
  frame.style.setProperty('--phone-h', m.altura + 'px');

  if (config.modelo === 'horizontal') frame.classList.add('landscape');
  else frame.classList.remove('landscape');

  aplicarEscala();
  atualizarStatusModelo();
}

function aplicarEscala() {
  const frame = document.getElementById('phone-frame');
  frame.style.transform = `scale(${config.escala / 100})`;
}

function aplicarOrientacaoApp(isGame) {
  const frame = document.getElementById('phone-frame');
  const m = MODELOS[config.modelo] || MODELOS.padrao;

  if (isGame && config.forcarLandscapeJogo && config.modelo !== 'horizontal') {
    frame.classList.add('landscape');
    frame.style.setProperty('--phone-w', m.altura + 'px');
    frame.style.setProperty('--phone-h', m.largura + 'px');
    if (config.modoImersivo) frame.classList.add('immersive');
  } else if (config.modelo === 'horizontal') {
    frame.classList.add('landscape');
    frame.style.setProperty('--phone-w', m.largura + 'px');
    frame.style.setProperty('--phone-h', m.altura + 'px');
    if (isGame && config.modoImersivo) frame.classList.add('immersive');
  } else {
    frame.classList.remove('landscape', 'immersive');
    frame.style.setProperty('--phone-w', m.largura + 'px');
    frame.style.setProperty('--phone-h', m.altura + 'px');
  }
  aplicarEscala();
}

function atualizarStatusModelo() {
  const el = document.getElementById('status-model');
  const m = MODELOS[config.modelo];
  if (el && m) el.textContent = m.nome;
}

// ============================================================
// CATÁLOGO (Junta os da pasta com os Importados)
// ============================================================
async function carregarCatalogo() {
  if (catalogoCarregado) return catalogo;
  catalogo = [];
  
  try {
    const r = await fetch('lista.txt', { cache: 'no-store' });
    if (r.ok) {
      const txt = await r.text();
      const pastas = txt.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#'));
      catalogo = pastas.map(p => ({ id: p, pasta: p, importado: false }));
    }
  } catch(e) { console.warn('lista.txt não encontrada'); }

  Object.keys(appsImportados).forEach(id => {
    catalogo.push({ id: id, pasta: id, importado: true });
  });

  await Promise.all(catalogo.map(async app => {
    app.nome = await lerNomeApp(app.pasta, app.pasta);
    app.isGame = await lerIsGame(app.pasta);
  }));

  catalogoCarregado = true;
  return catalogo;
}

function recarregarCatalogo() {
  catalogoCarregado = false;
  return carregarCatalogo();
}

function atualizarRelogio() {
  const d = new Date();
  document.getElementById('clock').textContent =
    `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}
setInterval(atualizarRelogio, 1000);
atualizarRelogio();

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function goHome() {
  const iframe = document.getElementById('app-iframe');
  iframe.src = 'about:blank';
  document.getElementById('phone-frame').classList.remove('immersive', 'show-bars');
  aplicarModelo();
  renderHome();
  showScreen('home-screen');
}

async function openStore() {
  aplicarModelo();
  await recarregarCatalogo();
  renderStore();
  showScreen('store-screen');
}

function openSettings() {
  aplicarModelo();
  renderSettings();
  showScreen('settings-screen');
}

// ============================================================
// RENDERS
// ============================================================
async function renderHome() {
  const grid = document.getElementById('app-grid');
  grid.innerHTML = '';
  const ids = Object.keys(instalados);
  if (ids.length === 0) {
    grid.innerHTML = '<p class="empty-msg">Nenhum app instalado.<br>Abra a Play Store 🛍️</p>';
    return;
  }
  await carregarCatalogo();
  for (const id of ids) {
    const app = instalados[id];
    const nome = await lerNomeApp(app.pasta, app.nome);
    const el = document.createElement('div');
    el.className = 'app-icon';
    const icon = criarIconeApp(app.pasta, nome);
    const label = document.createElement('span');
    label.textContent = nome;
    const del = document.createElement('div');
    del.className = 'delete-badge';
    del.textContent = '×';
    del.onclick = (e) => {
      e.stopPropagation();
      if (confirm(`Desinstalar "${nome}"?`)) desinstalar(id);
    };
    el.appendChild(icon);
    el.appendChild(label);
    el.appendChild(del);
    el.onclick = () => abrirApp(id);
    grid.appendChild(el);
  }
}

async function renderStore() {
  const list = document.getElementById('store-list');
  list.innerHTML = '';
  if (catalogo.length === 0) {
    list.innerHTML = '<p class="empty-msg">Nenhum app na loja.<br>Coloque nomes no lista.txt ou clique em Importar.</p>';
    return;
  }
  for (const item of catalogo) {
    const nome = item.nome || item.pasta;
    const instalado = !!instalados[item.id];
    const tipo = item.isGame ? '🎮 Jogo' : '📱 App';
    const origem = item.importado ? '📦 Importado' : '📁 Pasta';
    
    const el = document.createElement('div');
    el.className = 'store-item';
    const icon = criarIconeApp(item.pasta, nome);
    const info = document.createElement('div');
    info.className = 'store-item-info';
    info.innerHTML = `<h3>${nome}</h3><p>${tipo} · ${origem}</p>`;
    const btn = document.createElement('button');
    if (instalado) {
      btn.textContent = 'Desinstalar';
      btn.className = 'uninstall';
      btn.onclick = () => { if (confirm(`Desinstalar "${nome}"?`)) desinstalar(item.id); };
    } else {
      btn.textContent = 'Instalar';
      btn.onclick = () => instalar(item);
    }
    el.appendChild(icon);
    el.appendChild(info);
    el.appendChild(btn);
    list.appendChild(el);
  }
}

function renderSettings() {
  const list = document.getElementById('model-list');
  list.innerHTML = '';
  Object.entries(MODELOS).forEach(([chave, m]) => {
    const opt = document.createElement('div');
    opt.className = 'model-option' + (config.modelo === chave ? ' selected' : '');
    const prev = document.createElement('div');
    prev.className = 'model-preview' + (chave === 'horizontal' ? ' wide' : '');
    const info = document.createElement('div');
    info.className = 'model-info';
    info.innerHTML = `<strong>${m.nome}</strong><small>${m.desc}</small>`;
    opt.appendChild(prev);
    opt.appendChild(info);
    opt.onclick = () => { config.modelo = chave; salvarConfig(); aplicarModelo(); renderSettings(); };
    list.appendChild(opt);
  });

  const slider = document.getElementById('scale-slider');
  slider.value = config.escala;
  document.getElementById('scale-label').textContent = config.escala + '%';
  slider.oninput = () => {
    config.escala = parseInt(slider.value);
    document.getElementById('scale-label').textContent = config.escala + '%';
    aplicarEscala();
    salvarConfig();
  };

  const toggle = document.getElementById('force-game-landscape');
  toggle.checked = config.forcarLandscapeJogo;
  toggle.onchange = () => { config.forcarLandscapeJogo = toggle.checked; salvarConfig(); };

  const toggleImersivo = document.getElementById('immersive-game');
  toggleImersivo.checked = config.modoImersivo;
  toggleImersivo.onchange = () => { config.modoImersivo = toggleImersivo.checked; salvarConfig(); };

  document.getElementById('settings-info').textContent =
    `Modelo: ${MODELOS[config.modelo].nome} · Escala: ${config.escala}%`;
}

// ============================================================
// INSTALAR / DESINSTALAR / ABRIR
// ============================================================
async function instalar(item) {
  const [nome, isGame] = await Promise.all([
    lerNomeApp(item.pasta, item.pasta),
    lerIsGame(item.pasta)
  ]);
  instalados[item.id] = { nome, pasta: item.pasta, isGame, importado: item.importado };
  localStorage.setItem('apps_instalados', JSON.stringify(instalados));
  renderStore();
  alert(`✅ "${nome}" instalado!`);
}

function desinstalar(id) {
  const nome = instalados[id]?.nome || id;
  delete instalados[id];
  localStorage.setItem('apps_instalados', JSON.stringify(instalados));
  renderStore();
  renderHome();
  alert(`🗑️ "${nome}" desinstalado.`);
}

async function abrirApp(id) {
  const app = instalados[id];
  if (!app) return;

  const isGame = await lerIsGame(app.pasta);
  app.isGame = isGame;
  aplicarOrientacaoApp(isGame);

  const iframe = document.getElementById('app-iframe');
  
  if (app.importado && appsImportados[app.pasta]) {
    // Para o HTML do ZIP funcionar, criamos um Blob e liberamos o sandbox do iframe
    const html = appsImportados[app.pasta].html;
    const blob = new Blob([html], { type: 'text/html' });
    iframe.removeAttribute('sandbox'); // Permite scripts dentro do jogo
    iframe.src = URL.createObjectURL(blob);
  } else {
    // Carrega da pasta do sistema
    iframe.removeAttribute('sandbox');
    iframe.src = `app/${app.pasta}/index.html`;
  }
  
  showScreen('app-screen');
}

// ============================================================
// SISTEMA DE GESTO
// ============================================================
let touchStartY = 0;
const gestureBar = document.getElementById('gesture-bar');
const phoneFrame = document.getElementById('phone-frame');

gestureBar.addEventListener('touchstart', (e) => { touchStartY = e.touches[0].clientY; }, { passive: true });
gestureBar.addEventListener('touchmove', (e) => {
  if (touchStartY - e.touches[0].clientY > 20) phoneFrame.classList.add('show-bars');
}, { passive: true });

gestureBar.addEventListener('mousedown', (e) => { touchStartY = e.clientY; });
gestureBar.addEventListener('mousemove', (e) => {
  if (e.buttons !== 1) return;
  if (touchStartY - e.clientY > 20) phoneFrame.classList.add('show-bars');
});
gestureBar.addEventListener('click', () => phoneFrame.classList.add('show-bars'));

// ============================================================
// IMPORTAR APP VIA ZIP (Agora Completo)
// ============================================================
async function importarApp(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  if (!file.name.endsWith('.zip')) {
    alert('Por favor, envie um arquivo .zip');
    event.target.value = '';
    return;
  }

  const zip = new JSZip();
  try {
    const contents = await zip.loadAsync(file);
    
    let htmlContent = '';
    let nameTxt = 'App Importado';
    let typeTxt = 'is Game: false';
    let iconBase64 = null;
    
    // Cria um ID único baseado no nome do arquivo
    const folderName = 'import_' + file.name.replace('.zip', '').toLowerCase().replace(/[^a-z0-9]/g, '') + '_' + Date.now();

    // Varre todos os arquivos de dentro do ZIP (ignora pastas ocultas tipo MACOSX)
    for (const [filename, fileData] of Object.entries(contents.files)) {
      if (fileData.dir || filename.includes('__MACOSX')) continue;
      
      const lower = filename.toLowerCase();
      
      if (lower.endsWith('index.html')) {
        htmlContent = await fileData.async('string');
      } else if (lower.endsWith('name.txt')) {
        nameTxt = (await fileData.async('string')).trim();
      } else if (lower.endsWith('type.txt')) {
        typeTxt = await fileData.async('string');
      } else if (lower.endsWith('icon.png') || lower.endsWith('icon.jpg') || lower.endsWith('icon.jpeg') || lower.endsWith('icon.webp')) {
        // Converte o ícone para Base64 para salvar no localStorage
        const base64 = await fileData.async('base64');
        const ext = lower.split('.').pop();
        const mime = ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg';
        iconBase64 = `data:${mime};base64,${base64}`;
      }
    }

    if (!htmlContent) {
      throw new Error('O arquivo ZIP não contém um index.html');
    }

    // Verifica se é jogo no type.txt
    const limpoType = typeTxt.toLowerCase().replace(/[\s:_\-]+/g, '');
    const isGame = limpoType.includes('true') || limpoType.includes('1');

    // Salva no armazenamento
    appsImportados[folderName] = {
      html: htmlContent,
      nome: nameTxt || file.name.replace('.zip', ''),
      isGame: isGame,
      icon: iconBase64
    };

    localStorage.setItem('apps_importados', JSON.stringify(appsImportados));
    
    alert(`✅ "${nameTxt}" foi importado com sucesso!\nAgora clique em Instalar.`);
    
    // Recarrega a loja para mostrar o novo app
    await recarregarCatalogo();
    renderStore();

  } catch (error) {
    console.error(error);
    alert('❌ Erro ao importar: ' + error.message);
  } finally {
    event.target.value = ''; // Limpa o input para permitir importar outro
  }
}

// ============================================================
// LIMPAR TUDO
// ============================================================
function limparTodosApps() {
  if (confirm('Tem certeza? Isso apagará todos os apps importados e os instalados.')) {
    instalados = {};
    appsImportados = {};
    localStorage.removeItem('apps_instalados');
    localStorage.removeItem('apps_importados');
    recarregarCatalogo();
    goHome();
  }
}

// INIT
(async () => {
  aplicarModelo();
  await carregarCatalogo();
  renderHome();
})();